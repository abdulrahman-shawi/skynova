import * as React from 'react';

interface IDashboardPageProps {
}

const DashboardPage: React.FunctionComponent<IDashboardPageProps> = (props) => {
  return (
    <div className="">4</div>
  );
};

export default DashboardPage;
